### Hexlet tests and linter status:
[![Actions Status](https://github.com/Zorinap330/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Zorinap330/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b1d42cfc7d6cc3750fb5/maintainability)](https://codeclimate.com/github/Zorinap330/python-project-49/maintainability)
