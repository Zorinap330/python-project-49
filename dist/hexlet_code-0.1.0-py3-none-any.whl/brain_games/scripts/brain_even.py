#!/usr/bin/env python3

def main_even():
    from brain_games.scripts.brain_games import main
    main()
    print('Answer "yes" if the number is even, otherwise answer "no".')
